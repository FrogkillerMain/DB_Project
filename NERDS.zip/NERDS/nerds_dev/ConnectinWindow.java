package nerds_dev;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import nerds_dev.DAO.ClientDAO;
import nerds_dev.Loyauts.AdminLoyaut;
import nerds_dev.Loyauts.UserLoyaut;

public class ConnectinWindow extends JFrame{

	private static JPanel contentPane;

	public static int input_size = 10;
	public static Font font = new Font("Arial", Font.PLAIN, 15);
	public static JFrame frame = new JFrame("Connecting Frame");

	public static JComponent getTwoColumnLayout(JLabel[] labels, JComponent[] fields, boolean addMnemonics) {
		if (labels.length != fields.length) {
			String s = labels.length + " labels supplied for " + fields.length + " fields!";
			throw new IllegalArgumentException(s);
		}

		JComponent panel = new JPanel();
		GroupLayout layout = new GroupLayout(panel);
		panel.setLayout(layout);

		layout.setAutoCreateGaps(true);

		GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
		GroupLayout.Group yLabelGroup = layout.createParallelGroup(GroupLayout.Alignment.TRAILING);
		hGroup.addGroup(yLabelGroup);
		GroupLayout.Group yFieldGroup = layout.createParallelGroup();
		hGroup.addGroup(yFieldGroup);
		layout.setHorizontalGroup(hGroup);

		GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
		layout.setVerticalGroup(vGroup);

		int p = GroupLayout.PREFERRED_SIZE;

		for (JLabel label : labels) {
			yLabelGroup.addComponent(label);
		}

		for (Component field : fields) {
			yFieldGroup.addComponent(field, p, p, p);
		}

		for (int ii = 0; ii < labels.length; ii++) {
			vGroup.addGroup(layout.createParallelGroup().addComponent(labels[ii]).addComponent(fields[ii], p, p, p));
		}

		if (addMnemonics) {
			addMnemonics(labels, fields);
		}

		return panel;
	}

	private final static void addMnemonics(JLabel[] labels, JComponent[] fields) {
		Map<Character, Object> m = new HashMap<Character, Object>();
		for (int ii = 0; ii < labels.length; ii++) {
			labels[ii].setLabelFor(fields[ii]);
			String lwr = labels[ii].getText().toLowerCase();
			for (int jj = 0; jj < lwr.length(); jj++) {
				char ch = lwr.charAt(jj);
				if (m.get(ch) == null && Character.isLetterOrDigit(ch)) {
					m.put(ch, ch);
					labels[ii].setDisplayedMnemonic(ch);
					break;
				}
			}
		}
	}

	public static JComponent getTwoColumnLayout(String[] labelStrings, JComponent[] fields) {
		JLabel[] labels = new JLabel[labelStrings.length];
		for (int ii = 0; ii < labels.length; ii++) {
			labels[ii] = new JLabel(labelStrings[ii]);
			labels[ii].setFont(font);
		}
		return getTwoColumnLayout(labels, fields);
	}

	public static JComponent getTwoColumnLayout(JLabel[] labels, JComponent[] fields) {
		return getTwoColumnLayout(labels, fields, true);
	}

	public static String getProperty(String name) {
		return name + ": \t" + System.getProperty(name) + System.getProperty("line.separator");
	}

	public static JTextField[] components = { new JTextField(input_size), new JTextField(input_size) };

	public ConnectinWindow() {

		String[] labels = { " Name:", " Password:", };
		JComponent labelsAndFields = getTwoColumnLayout(labels, components);
		components[0].setAction(copy);
		components[1].setAction(copy);
		
		contentPane = new JPanel();
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

		JLabel lab = new JLabel("Please login:");
		lab.setAlignmentX(Component.CENTER_ALIGNMENT);
		lab.setFont(font);
		contentPane.add(Box.createRigidArea(new Dimension(0, 5)));
		contentPane.add(lab);
		contentPane.add(Box.createRigidArea(new Dimension(0, 18)));
		contentPane.add(labelsAndFields);
		contentPane.add(Box.createRigidArea(new Dimension(0, 12)));

		JButton LoginButton = new JButton("Login");
		LoginButton.setAction(copy);
		LoginButton.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "Login");
		LoginButton.getActionMap().put("Login", copy);

		contentPane.add(LoginButton);


		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(contentPane, BorderLayout.CENTER);
		frame.pack();
		frame.setVisible(true);
	}
	
	public static  void CheckValidation(String _login, String _pass)
	{
		if(_login.equals("admin")&&_pass.equals("admin"))
		{
			//MAIN ADMIN
			JOptionPane.showMessageDialog(contentPane, "Hello admin","Loged", JOptionPane.INFORMATION_MESSAGE);
			DB_connector.current_table = "Clients";
			DB_connector.current_PK = "id_client";
			AdminLoyaut.main("Clients");
			
			frame.dispose();
		}
		else if(ClientDAO.validate(_login,_pass))
		{
			//CLIENT
			JOptionPane.showMessageDialog(contentPane, "Hello user","Loged", JOptionPane.INFORMATION_MESSAGE);
            UserLoyaut.main();
			frame.dispose();
		}
		else
		{					
			JOptionPane.showMessageDialog(contentPane, "Sorry, Username or Password Error","Login Error!", JOptionPane.ERROR_MESSAGE);
			clear_input();
		}		
	}

	
	 private static Action copy = new AbstractAction("Login")
	 {
	        public void actionPerformed(ActionEvent e)
	        {
				CheckValidation(components[0].getText(),components[1].getText());
	        }
	 };
	
	public static void clear_input()
	{		
		components[0].setText("");
		components[1].setText("");	
	}

}
