package nerds_dev;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextField;



public class DB_connector 
{
    private static boolean status = false;
    protected String user;
    protected String password;
    
    public static boolean get_status() 
    {
       return status;
    }
    
    
    public static String current_table;
    public static String current_PK;
    
	public static Connection getConnection()
    {
	    String url = "jdbc:mysql://localhost:3306/nerds_db";
	    Statement statement;
		Connection connector = null;
		
	    try 
	    {
	    	connector = DriverManager.getConnection(url, "root", "cm=fyeMb!2ZA");
	        statement = connector.createStatement();
	        System.out.println("Database connected!");
	        status = true;
	    } catch (SQLException connectException)
	    {
	      System.out.println(connectException.getMessage());
	      System.out.println(connectException.getSQLState());
	      System.out.println(connectException.getErrorCode());
	    }

	    return connector;
	  }

	  private void displaySQLErrors(SQLException e) 
	  {
	    System.out.println("SQLException: " + e.getMessage() + "\n");
	    System.out.println("SQLState:     " + e.getSQLState() + "\n");
	    System.out.println("VendorError:  " + e.getErrorCode() + "\n");
	  }
	  private static int getRowCount(ResultSet resultSet)
	  {
		    if (resultSet == null) {
		        return 0;
		    }
		    try {
		        resultSet.last();
		        return resultSet.getRow();
		    } catch (SQLException exp) {
		        exp.printStackTrace();
		    } finally {
		        try {
		            resultSet.beforeFirst();
		        } catch (SQLException exp) {
		            exp.printStackTrace();
		        }
		    }
		    return 0;
		}

	  public static String[] sql_getPlus(String table_name, String _couse) 
	  {
		  String[] data = null;
		  try {
		  String query = "SELECT * FROM "+table_name+" ";

	      Connection _connector = DB_connector.getConnection();
	      Statement st = _connector.createStatement();
	      
	      ResultSet rs = st.executeQuery(query);
	      
	      data = new String[getRowCount(rs)];
	      
	      int i=0;
	      while (rs.next())
	      {	       
	    	  data[i] = rs.getString(_couse);
	    	  i++;	        
	      }
	      st.close();
	      _connector.close();
			}catch(Exception e){System.out.println(e);}

		return data;
	  }
	  
	  
	  private static String[] sql_getAll(String table_name,String PK) 
	  {
			PreparedStatement sql_st;
			Connection _connector = DB_connector.getConnection();
			ResultSetMetaData rsmd;
			ResultSet rs;
			String data[] = null;
		  try {
				sql_st = _connector.prepareStatement("select * from "+table_name+" WHERE (`"+current_PK+"` = '"+PK+"')", ResultSet.TYPE_SCROLL_SENSITIVE,
						ResultSet.CONCUR_UPDATABLE);
				rs = sql_st.executeQuery();



				rsmd = rs.getMetaData();
				int cols = rsmd.getColumnCount();
				data = new String[cols];

				for (int i = 1; i <= cols; i++) 
				{
					data[i - 1] = rsmd.getColumnName(i);
					//System.out.println(data[i]);
				}

			} catch (SQLException e) {

				e.printStackTrace();
			}
		  return data;
	  }
	 
	  public static boolean sql_modificate_field(String table_name,String PK, String[] _my_data)
	  {
		    String sql_data[] = sql_getAll(table_name,PK);
		    String querry = " ";
		    for(int i=1;i<_my_data.length;i++)
		    {
		    		querry+=("`"+sql_data[i]+"` = '"+_my_data[i]+"'");		
		    		if(i<_my_data.length-1)
		    			{
		    			
		    			querry+=(", ");
		    			}
		    }
		    
			boolean status=false;
			
			try
			{
				Connection _connector=DB_connector.getConnection();
				String querr = ("UPDATE `nerds_db`.`"+table_name+"` SET "+querry+" WHERE (`"+current_PK+"` = '"+PK+"')");
				PreparedStatement sql_st=_connector.prepareStatement(querr.toString());

				System.out.println(querr.toString());

				int rs=sql_st.executeUpdate();
	
				System.out.println(table_name+" - Modificated!");
				_connector.close();
			}catch(Exception e){System.out.println(e);}
			
			
			return status;
		}
}
