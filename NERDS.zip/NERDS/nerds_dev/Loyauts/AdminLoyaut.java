package nerds_dev.Loyauts;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;

import nerds_dev.DB_connector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.sql.*;

public class AdminLoyaut extends JFrame 
{
	static AdminLoyaut frame;
	private JPanel contentPane;
	private static JTable table;
	
	public static void main(String args) 
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new AdminLoyaut(args.toString());
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public AdminLoyaut(String _dataTable) 
	{
		setTitle("Admin tools");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH); 
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(4, 4));
		setContentPane(contentPane);
	    add(AdminInput.Add_window(_dataTable), BorderLayout.WEST); 
		String data[][]=null;
		String column[]=null;
		
		   
		
		set_TopBar();
		
		try{
			Connection con=DB_connector.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from "+_dataTable.toString()+" ",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols=rsmd.getColumnCount();
			column=new String[cols];
			for(int i=1;i<=cols;i++){
				column[i-1]=rsmd.getColumnName(i);
			}
			
			rs.last();
			int rows=rs.getRow();
			rs.beforeFirst();

			data=new String[rows][cols];
			int count=0;
			
			while(rs.next()){
				for(int i=1;i<=cols;i++){
					data[count][i-1]=rs.getString(i);
				}
				count++;
			}
			con.close();
		}catch(Exception e){System.out.println(e);}

		table = new JTable(data,column);
		JScrollPane sp=makeResultTable(table);
		
		contentPane.add(sp, BorderLayout.CENTER);
	
		pack();
	}

		
	public static int selected_theme;
	 
	private JScrollPane makeResultTable(JTable resultTable) 
    {
                
                resultTable.addMouseListener(new java.awt.event.MouseAdapter() 
                {
                @Override
                public void mouseReleased(java.awt.event.MouseEvent evt)
                {
                    int row = resultTable.rowAtPoint(evt.getPoint());
                    int col = resultTable.columnAtPoint(evt.getPoint());
                    
                    if(row>=0)
                    {  
                    	for(int i=0;i<resultTable.getColumnCount();i++)
                    	{
                    		AdminInput.components[i].setText((String)resultTable.getValueAt(row, i));
                        }
                    }
                    
                }
                });
                
		JScrollPane scrollPane = new JScrollPane(resultTable);
		                             
		return scrollPane;
	}
	
	private void set_TopBar()
	{
		var menubar = new JMenuBar();
		
	//**********************
	    var view_pick = new JMenu("View");
	    view_pick.setMnemonic(KeyEvent.VK_E);
	    
	    
	    var managers_view_pick = new JMenuItem("Managers");
	    managers_view_pick.setToolTipText("View managers");
	    managers_view_pick.addActionListener((event) -> 
		{
			
			  AdminLoyaut.main("Managers");
			  DB_connector.current_table = "Managers";
			  DB_connector.current_PK = "id_manager";
			  frame.dispose();
				   
		});
	        
	    
	    var clients_view_pick = new JMenuItem("Clients");
	    clients_view_pick.setToolTipText("View clients");
	    clients_view_pick.addActionListener((event) -> 
		{
		
			  AdminLoyaut.main("Clients");
			  DB_connector.current_table = "Clients";
			  DB_connector.current_PK = "id_client";
			  frame.dispose();
				   
		});
	    
	    var departaments_view_pick = new JMenuItem("Departaments");
	    departaments_view_pick.setToolTipText("View departaments");
	    departaments_view_pick.addActionListener((event) -> 
		{
		
			  AdminLoyaut.main("Departments");
			  DB_connector.current_PK = "id_department";
			  DB_connector.current_table = "Departments";
			  frame.dispose();
				   
		});
	    
	    var masters_view_pick = new JMenuItem("Masters");
	    masters_view_pick.setToolTipText("View masters");
	    masters_view_pick.addActionListener((event) -> 
		{
		
			  AdminLoyaut.main("Masters");
			  DB_connector.current_PK = "id_master";
			  DB_connector.current_table = "Masters";
			  frame.dispose();
				   
		});
	    
	    var curriers_view_pick = new JMenuItem("Curriers");
	    curriers_view_pick.setToolTipText("View curriers");
	    curriers_view_pick.addActionListener((event) -> 
		{
		
			  AdminLoyaut.main("Curriers");
			  DB_connector.current_PK = "id_currier";
			  DB_connector.current_table = "Curriers";
			  frame.dispose();
				   
		});
	    	    
	    
	    view_pick.add(clients_view_pick);
	    view_pick.add(managers_view_pick);  
	    view_pick.add(departaments_view_pick);
	    view_pick.add(masters_view_pick);
	    view_pick.add(curriers_view_pick);

	    
	    menubar.add(view_pick);    
	//**********************
	    var file_pick = new JMenu("File");
	  
	    var exit_file_pick = new JMenuItem("Exit");
	    exit_file_pick.setToolTipText("Exit app");
	    exit_file_pick.addActionListener((event) -> System.exit(0));
	    file_pick.add(exit_file_pick);
	   
	    
	    menubar.add(file_pick);    
	//**********************
 
	    menubar.add(view_pick);    
	    setJMenuBar(menubar);	
	 	      
	}
	
	
}
