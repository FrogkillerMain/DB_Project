package nerds_dev.Loyauts;
import java.util.List;
import javax.swing.table.AbstractTableModel;

import nerds_dev.DAO.ClientDAO;

public class ClientsList extends AbstractTableModel 
{	
  private List<ClientDAO> aspirantsList;

  ClientsList(List<ClientDAO> cityList) 
        {
	  this.aspirantsList = cityList;
	}
	
	private String[] colNames = {"ID","Name"};
        	
	@Override
	public String getColumnName(int column)
        {
		return colNames[column];
	}

	@Override
	public int getColumnCount()
        {
		return colNames.length;
	}
	
	@Override
	public int getRowCount() 
        {
		return aspirantsList.size();
	}
     
	@Override
	public Object getValueAt(int row, int column)
     {
	  if(row < 0 || row >= aspirantsList.size()) return null;
	  ClientDAO obj = aspirantsList.get(row);
        
            switch(column)
            {
                case 0: return obj.get_userID();
                case 1: return obj.get_userName();
              
                default: return null;
            }
	}
}


