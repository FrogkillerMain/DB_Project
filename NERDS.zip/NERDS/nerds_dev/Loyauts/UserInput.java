
package nerds_dev.Loyauts;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

import nerds_dev.DB_connector;
import nerds_dev.DatePicker;
import nerds_dev.ViewSubmitions;
import nerds_dev.DAO.ClientDAO;
import nerds_dev.DAO.Order;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

class UserInput {
	
	  public static int input_size = 10;
	    public static Font font = new Font("Arial", Font.PLAIN,15);
	    private static Connection connection;
	    
	    public static JComponent getTwoColumnLayout(JLabel[] labels, JComponent[] fields, boolean addMnemonics) 
	    {
	        if (labels.length != fields.length) 
	        {
	            String s = labels.length + " labels supplied for "
	                    + fields.length + " fields!";
	            throw new IllegalArgumentException(s);
	        }
	        
	        JComponent panel = new JPanel();
	        GroupLayout layout = new GroupLayout(panel);
	        panel.setLayout(layout);
	     
	        layout.setAutoCreateGaps(true);
	       
	        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
	        GroupLayout.Group yLabelGroup = layout.createParallelGroup(GroupLayout.Alignment.TRAILING);
	        hGroup.addGroup(yLabelGroup);
	        GroupLayout.Group yFieldGroup = layout.createParallelGroup();
	        hGroup.addGroup(yFieldGroup);
	        layout.setHorizontalGroup(hGroup);
	       
	        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
	        layout.setVerticalGroup(vGroup);

	        int p = GroupLayout.PREFERRED_SIZE;
	       
	        for (JLabel label : labels) 
	        {
	            yLabelGroup.addComponent(label);
	        }
	        
	        for (Component field : fields)
	        {
	            yFieldGroup.addComponent(field, p, p, p);
	        }
	        
	        for (int ii = 0; ii < labels.length; ii++)
	        {
	            vGroup.addGroup(layout.createParallelGroup().
	                    addComponent(labels[ii]).
	                    addComponent(fields[ii], p, p, p));
	        }

	        if (addMnemonics) 
	        {
	            addMnemonics(labels, fields);
	        }

	        return panel;
	    }

	    private final static void addMnemonics(JLabel[] labels,JComponent[] fields) 
	    {
	        Map<Character, Object> m = new HashMap<Character, Object>();
	        for (int ii = 0; ii < labels.length; ii++) 
	        {
	            labels[ii].setLabelFor(fields[ii]);
	            String lwr = labels[ii].getText().toLowerCase();
	            for (int jj = 0; jj < lwr.length(); jj++) 
	            {
	                char ch = lwr.charAt(jj);
	                if (m.get(ch) == null && Character.isLetterOrDigit(ch))
	                {
	                    m.put(ch, ch);
	                    labels[ii].setDisplayedMnemonic(ch);
	                    break;
	                }
	            }
	        }
	    }

	    public static JComponent getTwoColumnLayout(String[] labelStrings, JComponent[] fields) 
	    { 
	        JLabel[] labels = new JLabel[labelStrings.length];
	        for (int ii = 0; ii < labels.length; ii++)
	        {
	            labels[ii] = new JLabel(labelStrings[ii]);
	            labels[ii].setFont(font);
	        }
	        return getTwoColumnLayout(labels, fields);
	    }

	    public static JComponent getTwoColumnLayout(JLabel[] labels,JComponent[] fields) 
	    {
	        return getTwoColumnLayout(labels, fields, true);
	    }

	    public static String getProperty(String name) 
	    {
	        return name + ": \t"
	                    + System.getProperty(name)
	                    + System.getProperty("line.separator");
	    }

	 private static JButton addButton ;
	 private static JButton submitButton ;
	 private static JButton deleteButton ;
	 
	    public static JPanel makeControlPanel()
	    {
			JPanel contolPanel = new JPanel();

			 submitButton = new JButton("Submit");				
			 deleteButton = new JButton("Cancel");				             
	         addButton = new JButton("View all submitions");

	         submitButton.addActionListener(new ActionListener() 
             {
               @Override
               public void actionPerformed(ActionEvent e) 
               {
                 try {

                 Order.SaveOrder(
                 new Order(
                 "12",
                 components[2].getText(), 
                 components[1].getText(), 
                 "3",
                 String.valueOf(combo_components[1].getSelectedIndex()+1)));
                 
                 
                 } catch (Exception ei) {
                   ei.printStackTrace();
                 }
                             
               }

              });    
	               
	         addButton.addActionListener(new ActionListener() 
             {
               @Override
               public void actionPerformed(ActionEvent e) 
               {
                 try 
                 {
                	  ViewSubmitions.main();
          			  //UserLoyaut.frame.dispose();
                 
                 
                 } catch (Exception ei) {
                   ei.printStackTrace();
                 }
                             
               }

              });    
	                
	                contolPanel.add(submitButton);
	                contolPanel.add(deleteButton);
	                contolPanel.add(addButton);
	                
	                
	               
			return contolPanel;
	    }

	    public static JTextField[] components = 
	    {
	                    new JTextField(input_size),
	                    new JTextField(input_size),
	                    new JTextField(input_size),
	                    new JTextField(input_size),              
	    };

	    
	    private static  String[] _masters;
	    private static  String[] _exchange_device;
	     
	    private static JComboBox[] combo_components;
	                
	    public static void SetConnection(Connection _connection)   
	    {       
	         connection = _connection;        
	    }
	    
	    public static JComponent Add_window()
	    {
	    	  components[3].addMouseListener(new MouseAdapter(){
	              @Override
	              public void mouseClicked(MouseEvent e)
	              {
	            	  components[3].setText(new DatePicker(UserLoyaut.frame).setPickedDate());
	              }
	          });
	    	  
	    	  components[2].addMouseListener(new MouseAdapter(){
	              @Override
	              public void mouseClicked(MouseEvent e)
	              {
	            	  components[2].setText(new DatePicker(UserLoyaut.frame).setPickedDate());
	              }
	          });

	    	
	    	_masters = DB_connector.sql_getPlus("nerds_db.Masters","name");
	    	_exchange_device = new String[] {"Iphone", "Mac","PSP","Lenovo"} ;
	    	
	    	
	    	combo_components = new JComboBox[]
	        {
	                    new JComboBox(_masters),
	                    new JComboBox(_exchange_device),        
	        };
	    	
	                String[] labels = 
	                {
	                    " Service:",
	                    " Max price:",
	                    " Begin date:",
	                    " End date:",                  
	                };

	                String[] combo_labels = 
	                {
	                    " Master :",
	                    " Exchange device :",              
	                };

	                JComponent labelsAndFields = getTwoColumnLayout(labels,components);
	                JComponent labelsAndChoseFields = getTwoColumnLayout(combo_labels,combo_components);
	                JComponent orderForm = new JPanel();
	                orderForm.setLayout(new BoxLayout(orderForm, BoxLayout.Y_AXIS));
	               
	                JLabel lab = new JLabel("Fill info to complete");
	                lab.setAlignmentX(Component.CENTER_ALIGNMENT);
	                lab.setFont(font);
	                orderForm.add(Box.createRigidArea(new Dimension(0,5)));
	                orderForm.add(lab);
	                orderForm.add(Box.createRigidArea(new Dimension(0,18)));
	                orderForm.add(labelsAndFields);
	                orderForm.add(Box.createRigidArea(new Dimension(0,8)));
	                orderForm.add(labelsAndChoseFields);
	                orderForm.add(Box.createRigidArea(new Dimension(0,12)));
	                orderForm.add(makeControlPanel());
	      
	                //DepartamentApp.SaveAspirant(components);
	                return orderForm;
	    }
}
