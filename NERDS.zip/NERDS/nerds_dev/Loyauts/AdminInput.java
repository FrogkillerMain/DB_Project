package nerds_dev.Loyauts;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

import nerds_dev.DB_connector;

class AdminInput {
	
	public static int input_size = 10;
	public static Font font = new Font("Arial", Font.PLAIN, 15);
	private static Connection connection;

	public static JComponent getTwoColumnLayout(JLabel[] labels, JComponent[] fields, boolean addMnemonics) {
		if (labels.length != fields.length) {
			String s = labels.length + " labels supplied for " + fields.length + " fields!";
			throw new IllegalArgumentException(s);
		}

		JComponent panel = new JPanel();
		GroupLayout layout = new GroupLayout(panel);
		panel.setLayout(layout);

		layout.setAutoCreateGaps(true);

		GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
		GroupLayout.Group yLabelGroup = layout.createParallelGroup(GroupLayout.Alignment.TRAILING);
		hGroup.addGroup(yLabelGroup);
		GroupLayout.Group yFieldGroup = layout.createParallelGroup();
		hGroup.addGroup(yFieldGroup);
		layout.setHorizontalGroup(hGroup);

		GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
		layout.setVerticalGroup(vGroup);

		int p = GroupLayout.PREFERRED_SIZE;

		for (JLabel label : labels) {
			yLabelGroup.addComponent(label);
		}

		for (Component field : fields) {
			yFieldGroup.addComponent(field, p, p, p);
		}

		for (int ii = 0; ii < labels.length; ii++) {
			vGroup.addGroup(layout.createParallelGroup().addComponent(labels[ii]).addComponent(fields[ii], p, p, p));
		}

		if (addMnemonics) {
			addMnemonics(labels, fields);
		}

		return panel;
	}

	private final static void addMnemonics(JLabel[] labels, JComponent[] fields) {
		Map<Character, Object> m = new HashMap<Character, Object>();
		for (int ii = 0; ii < labels.length; ii++) {
			labels[ii].setLabelFor(fields[ii]);
			String lwr = labels[ii].getText().toLowerCase();
			for (int jj = 0; jj < lwr.length(); jj++) {
				char ch = lwr.charAt(jj);
				if (m.get(ch) == null && Character.isLetterOrDigit(ch)) {
					m.put(ch, ch);
					labels[ii].setDisplayedMnemonic(ch);
					break;
				}
			}
		}
	}

	public static JComponent getTwoColumnLayout(String[] labelStrings, JComponent[] fields) {
		JLabel[] labels = new JLabel[labelStrings.length];
		for (int ii = 0; ii < labels.length; ii++) {
			labels[ii] = new JLabel(labelStrings[ii]);
			labels[ii].setFont(font);
		}
		return getTwoColumnLayout(labels, fields);
	}

	public static JComponent getTwoColumnLayout(JLabel[] labels, JComponent[] fields) {
		return getTwoColumnLayout(labels, fields, true);
	}

	public static String getProperty(String name) {
		return name + ": \t" + System.getProperty(name) + System.getProperty("line.separator");
	}

	/*
	 * private static void addListners() {
	 * 
	 * deleteButton.addActionListener(new ActionListener() {
	 * 
	 * @Override public void actionPerformed(ActionEvent arg0) { try { // statement
	 * = connection.createStatement();
	 * //statement.executeUpdate("DELETE FROM aspirant WHERE theme = '"+
	 * selected_theme+"'");
	 * 
	 * System.out.println(selected_theme); //aspirantsList.remove() } catch
	 * (Exception e) { System.out.println(e); e.printStackTrace(); } } }); }
	 */
	private static JButton addButton;
	private static JButton modifyButton;
	private static JButton deleteButton;

	public static void ModifyMode(boolean _tag) {
		modifyButton.setEnabled(_tag);
		deleteButton.setEnabled(_tag);

	}

	public static JPanel makeControlPanel() 
	{
		JPanel contolPanel = new JPanel();

		modifyButton = new JButton("Modify");
		deleteButton = new JButton("Delete");
		addButton = new JButton("Create");

		modifyButton.addActionListener(new ActionListener() 
        {
          @Override
          public void actionPerformed(ActionEvent e) 
          {

            try 
            {
            	int cols = rsmd.getColumnCount();
            	String[] my_data_array = new String[cols];
            	
            	for (int i = 1; i < cols; i++) 
            	{
            		my_data_array[i] = components[i].getText();
            	 // System.out.println(my_data_array[i]);
            	 
            	}
            	
          	DB_connector.sql_modificate_field(DB_connector.current_table.toString(),components[0].getText(),my_data_array);        
            AdminLoyaut.main(DB_connector.current_table);
			AdminLoyaut.frame.dispose();
			
            } catch (Exception ei) 
            {
              ei.printStackTrace();
            }  
          }

        });
		contolPanel.add(modifyButton);
		contolPanel.add(deleteButton);
		contolPanel.add(addButton);

		return contolPanel;
	}

	static JTextField[] components;
	static ResultSetMetaData rsmd;
	static ResultSet rs;
	
	public static void SetConnection(Connection _connection) {
		connection = _connection;
	}

	public static JComponent Add_window(String _data_table) 
	{
		String column_labels[] = null;
		Connection _connector = DB_connector.getConnection();
		PreparedStatement sql_st;

		try {
			sql_st = _connector.prepareStatement("select * from "+_data_table.toString()+" ", ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			rs = sql_st.executeQuery();

			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			column_labels = new String[cols];
			components = new JTextField[cols];
			for (int i = 1; i <= cols; i++) {
				column_labels[i - 1] = rsmd.getColumnName(i);
				components[i-1] = new JTextField(input_size);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		JComponent labelsAndFields = getTwoColumnLayout(column_labels, components);
		JComponent orderForm = new JPanel();
		orderForm.setLayout(new BoxLayout(orderForm, BoxLayout.Y_AXIS));

		JLabel lab = new JLabel("Edit "+_data_table+" info");
		lab.setAlignmentX(Component.CENTER_ALIGNMENT);
        lab.setForeground(Color.BLUE);
		lab.setFont(font);
		orderForm.add(Box.createRigidArea(new Dimension(0, 5)));
		orderForm.add(lab);
		orderForm.add(Box.createRigidArea(new Dimension(0, 18)));
		orderForm.add(labelsAndFields);
		orderForm.add(Box.createRigidArea(new Dimension(0, 8)));
		orderForm.add(Box.createRigidArea(new Dimension(0, 12)));
		orderForm.add(makeControlPanel());

		// DepartamentApp.SaveAspirant(components);
		return orderForm;
	}
	

}
