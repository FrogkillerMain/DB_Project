package nerds_dev.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import nerds_dev.DB_connector;

public class Order 
{
    private String id;
    private String date_ordered;
    private String price;
    private String id_client;
    private String id_master;


    public Order(String _id, String _date_ordered, String _price,String _id_client,String _id_master)
    {
	this.id = _id;
	this.date_ordered = _date_ordered;
	this.price = _price;
    this.id_client = _id_client;
	this.id_master = _id_master;

    }
	
    public String getOrderId() 
    {
	return id;
    }
    
    public String getDateOrdered() 
    {
	return date_ordered;
    }
    
    public String getPrice() 
    {
	return price;
    }
    
    public String getClienID() 
    {
	return id_client;
    }
        
    public String getMasterID() 
    {
	return id_master;
    }   
    
    public static void SaveOrder(Order _order)
    {
        String _message = "INSERT INTO nerds_db.Order(date_ordered, price, Clients_id_client, Masters_Id_master) VALUES"
                            + "(  '" + _order.getDateOrdered() +"' , " 
                            + "  '" + _order.getPrice() +"' , " 
                            + "  '" + _order.getClienID() +"' , " 
                            + "  '" + _order.getMasterID() +"'  " 
                            + ") ;";
        
        System.out.println(_message);
         
        String result = " NULL ";
        Statement _statement;
    
        try
        { 
            ResultSet _rs = null ;
  	       Connection _connector = DB_connector.getConnection();

            _statement = _connector.createStatement();               
            _statement.executeUpdate(_message);
        }
        catch (Exception e) 
        {
           System.out.println(e);
       e.printStackTrace();
        }
              
    }
 
}
