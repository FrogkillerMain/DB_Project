package nerds_dev.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import nerds_dev.DB_connector;

public class ClientDAO 
{
    private String user_id;
    private String user_name;

    public ClientDAO(String user_id, String user_name)
    {
	this.user_id = user_id;
	this.user_name = user_name;
    }
	
    public String get_userID() 
    {
	return user_id;
    }
    
    public String get_userName() 
    {
	return user_name;
    }
    
	public static boolean validate(String name,String password)
	{
		boolean status=false;
		
		try{
			Connection _connector=DB_connector.getConnection();
			PreparedStatement sql_st=_connector.prepareStatement("select * from Clients where login=? and password=?");
			sql_st.setString(1,name);
			sql_st.setString(2,password);
			ResultSet rs=sql_st.executeQuery();
			status=rs.next();
			System.out.println("Client loged!");
			_connector.close();
		}catch(Exception e){System.out.println(e);}
		
		
		return status;
	}
	

}
